/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `campuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `campuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `responsible_person` varchar(255) NOT NULL,
  `identity_document` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `campuses_username_unique` (`username`),
  UNIQUE KEY `campuses_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `campuses` WRITE;
/*!40000 ALTER TABLE `campuses` DISABLE KEYS */;
INSERT INTO `campuses` VALUES
(1,'Universitas Jabal Ghafur','unigha','admin@unigha.ac.id','081234567890','Jl. Gle Gapui, Sigli, Aceh','Admin UNIGHA','campus-documents/VhhlZqHgTdwzAfYpSbgWQVGHoVjDMIYEuz04yx66.pdf','pending',NULL,'2026-11-05 21:20:49','2026-11-05 21:20:49'),
(2,'Kampus Demo Aceh Utara','demo_aceh_utara','aceh.utara@sipafik.test','081100000000','Alamat Demo Kampus Demo Aceh Utara, Aceh, Indonesia','Penanggung Jawab Demo 1',NULL,'approved',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(3,'Kampus Demo Pidie Jaya','demo_pidie_jaya','pidiejaya@sipafik.test','081100000001','Alamat Demo Kampus Demo Pidie Jaya, Aceh, Indonesia','Penanggung Jawab Demo 2',NULL,'approved',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(4,'Kampus Demo Bireuen','demo_bireuen','bireuen@sipafik.test','081100000002','Alamat Demo Kampus Demo Bireuen, Aceh, Indonesia','Penanggung Jawab Demo 3',NULL,'approved',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(5,'Kampus Demo Banda Aceh','demo_banda_aceh','bandaaceh@sipafik.test','081100000003','Alamat Demo Kampus Demo Banda Aceh, Aceh, Indonesia','Penanggung Jawab Demo 4',NULL,'approved',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(6,'Kampus Demo Aceh Besar','demo_aceh_besar','acehbesar@sipafik.test','081100000004','Alamat Demo Kampus Demo Aceh Besar, Aceh, Indonesia','Penanggung Jawab Demo 5',NULL,'approved',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(7,'Kampus Demo Pidie','demo_pidie','pidie@sipafik.test','081100000005','Alamat Demo Kampus Demo Pidie, Aceh, Indonesia','Penanggung Jawab Demo 6',NULL,'pending',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(8,'Kampus Demo Aceh Barat','demo_aceh_barat','acehbarat@sipafik.test','081100000006','Alamat Demo Kampus Demo Aceh Barat, Aceh, Indonesia','Penanggung Jawab Demo 7',NULL,'pending',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(9,'Kampus Demo Aceh Tengah','demo_aceh_tengah','acehtengah@sipafik.test','081100000007','Alamat Demo Kampus Demo Aceh Tengah, Aceh, Indonesia','Penanggung Jawab Demo 8',NULL,'pending',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48'),
(10,'Kampus Demo Lhokseumawe','demo_lhokseumawe','lhokseumawe@sipafik.test','081100000008','Alamat Demo Kampus Demo Lhokseumawe, Aceh, Indonesia','Penanggung Jawab Demo 9',NULL,'rejected','Dokumen persyaratan demo belum memenuhi ketentuan.','2026-11-14 20:42:48','2026-11-14 20:42:48');
/*!40000 ALTER TABLE `campuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `event_registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_registrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `campus_id` bigint(20) unsigned NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'registered',
  `registered_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_registrations_event_id_user_id_unique` (`event_id`,`user_id`),
  KEY `event_registrations_user_id_foreign` (`user_id`),
  KEY `event_registrations_campus_id_status_index` (`campus_id`,`status`),
  CONSTRAINT `event_registrations_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_registrations_event_id_foreign` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE,
  CONSTRAINT `event_registrations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `event_registrations` WRITE;
/*!40000 ALTER TABLE `event_registrations` DISABLE KEYS */;
INSERT INTO `event_registrations` VALUES
(1,1,29,2,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(2,2,29,2,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(3,3,29,2,'cancelled','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(4,1,30,2,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(5,3,30,2,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(6,5,30,2,'attended','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(7,7,34,3,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(8,8,34,3,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(9,9,34,3,'cancelled','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(10,7,35,3,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(11,9,35,3,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(12,11,35,3,'attended','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(13,13,39,4,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(14,14,39,4,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(15,15,39,4,'cancelled','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(16,13,40,4,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(17,15,40,4,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(18,17,40,4,'attended','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(19,19,44,5,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(20,20,44,5,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(21,21,44,5,'cancelled','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(22,19,45,5,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(23,21,45,5,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(24,23,45,5,'attended','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(25,25,49,6,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(26,26,49,6,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(27,27,49,6,'cancelled','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(28,25,50,6,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(29,27,50,6,'registered','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(30,29,50,6,'attended','2026-11-15 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(31,7,29,3,'registered','2026-11-16 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(32,13,34,4,'registered','2026-11-16 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(33,19,39,5,'registered','2026-11-16 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(34,25,44,6,'registered','2026-11-16 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(35,1,49,2,'registered','2026-11-16 00:00:00','2026-11-17 05:47:00','2026-11-17 05:47:00');
/*!40000 ALTER TABLE `event_registrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campus_id` bigint(20) unsigned NOT NULL,
  `organizer_id` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(30) NOT NULL DEFAULT 'seminar',
  `location` varchar(255) DEFAULT NULL,
  `event_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `quota` int(10) unsigned NOT NULL DEFAULT 50,
  `visibility` varchar(20) NOT NULL DEFAULT 'campus',
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `events_organizer_id_foreign` (`organizer_id`),
  KEY `events_campus_id_event_date_index` (`campus_id`,`event_date`),
  KEY `events_status_visibility_index` (`status`,`visibility`),
  CONSTRAINT `events_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `events_organizer_id_foreign` FOREIGN KEY (`organizer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES
(1,2,26,'Seminar Nasional Teknologi Kampus Demo Aceh Utara','Seminar Nasional Teknologi yang diselenggarakan di Kampus Demo Aceh Utara. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','seminar','Ruang Seminar','2026-11-27','09:00:00','12:00:00',100,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(2,2,28,'Workshop Pengembangan Aplikasi Web Kampus Demo Aceh Utara','Workshop Pengembangan Aplikasi Web yang diselenggarakan di Kampus Demo Aceh Utara. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','workshop','Laboratorium Komputer','2026-12-01','08:30:00','15:00:00',40,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(3,2,26,'Pelatihan Kepemimpinan Mahasiswa Kampus Demo Aceh Utara','Pelatihan Kepemimpinan Mahasiswa yang diselenggarakan di Kampus Demo Aceh Utara. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','pelatihan','Aula Kampus','2026-11-24','08:00:00','16:00:00',30,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(4,2,26,'Lomba Karya Tulis Ilmiah Kampus Demo Aceh Utara','Lomba Karya Tulis Ilmiah yang diselenggarakan di Kampus Demo Aceh Utara. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lomba','Gedung Rektorat','2026-12-08','09:00:00','14:00:00',60,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(5,2,28,'Bakti Sosial Mahasiswa Kampus Demo Aceh Utara','Bakti Sosial Mahasiswa yang diselenggarakan di Kampus Demo Aceh Utara. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','bakti_sosial','Desa Binaan','2026-11-12','07:30:00','12:00:00',25,'campus','completed','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(6,2,26,'Rapat Kerja Organisasi Kampus Demo Aceh Utara','Rapat Kerja Organisasi yang diselenggarakan di Kampus Demo Aceh Utara. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lainnya','Ruang Rapat','2026-12-17','13:00:00','16:00:00',20,'campus','draft','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(7,3,31,'Seminar Nasional Teknologi Kampus Demo Pidie Jaya','Seminar Nasional Teknologi yang diselenggarakan di Kampus Demo Pidie Jaya. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','seminar','Ruang Seminar','2026-11-27','09:00:00','12:00:00',100,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(8,3,33,'Workshop Pengembangan Aplikasi Web Kampus Demo Pidie Jaya','Workshop Pengembangan Aplikasi Web yang diselenggarakan di Kampus Demo Pidie Jaya. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','workshop','Laboratorium Komputer','2026-12-01','08:30:00','15:00:00',40,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(9,3,31,'Pelatihan Kepemimpinan Mahasiswa Kampus Demo Pidie Jaya','Pelatihan Kepemimpinan Mahasiswa yang diselenggarakan di Kampus Demo Pidie Jaya. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','pelatihan','Aula Kampus','2026-11-24','08:00:00','16:00:00',30,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(10,3,31,'Lomba Karya Tulis Ilmiah Kampus Demo Pidie Jaya','Lomba Karya Tulis Ilmiah yang diselenggarakan di Kampus Demo Pidie Jaya. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lomba','Gedung Rektorat','2026-12-08','09:00:00','14:00:00',60,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(11,3,33,'Bakti Sosial Mahasiswa Kampus Demo Pidie Jaya','Bakti Sosial Mahasiswa yang diselenggarakan di Kampus Demo Pidie Jaya. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','bakti_sosial','Desa Binaan','2026-11-12','07:30:00','12:00:00',25,'campus','completed','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(12,3,31,'Rapat Kerja Organisasi Kampus Demo Pidie Jaya','Rapat Kerja Organisasi yang diselenggarakan di Kampus Demo Pidie Jaya. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lainnya','Ruang Rapat','2026-12-17','13:00:00','16:00:00',20,'campus','draft','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(13,4,36,'Seminar Nasional Teknologi Kampus Demo Bireuen','Seminar Nasional Teknologi yang diselenggarakan di Kampus Demo Bireuen. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','seminar','Ruang Seminar','2026-11-27','09:00:00','12:00:00',100,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(14,4,38,'Workshop Pengembangan Aplikasi Web Kampus Demo Bireuen','Workshop Pengembangan Aplikasi Web yang diselenggarakan di Kampus Demo Bireuen. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','workshop','Laboratorium Komputer','2026-12-01','08:30:00','15:00:00',40,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(15,4,36,'Pelatihan Kepemimpinan Mahasiswa Kampus Demo Bireuen','Pelatihan Kepemimpinan Mahasiswa yang diselenggarakan di Kampus Demo Bireuen. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','pelatihan','Aula Kampus','2026-11-24','08:00:00','16:00:00',30,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(16,4,36,'Lomba Karya Tulis Ilmiah Kampus Demo Bireuen','Lomba Karya Tulis Ilmiah yang diselenggarakan di Kampus Demo Bireuen. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lomba','Gedung Rektorat','2026-12-08','09:00:00','14:00:00',60,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(17,4,38,'Bakti Sosial Mahasiswa Kampus Demo Bireuen','Bakti Sosial Mahasiswa yang diselenggarakan di Kampus Demo Bireuen. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','bakti_sosial','Desa Binaan','2026-11-12','07:30:00','12:00:00',25,'campus','completed','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(18,4,36,'Rapat Kerja Organisasi Kampus Demo Bireuen','Rapat Kerja Organisasi yang diselenggarakan di Kampus Demo Bireuen. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lainnya','Ruang Rapat','2026-12-17','13:00:00','16:00:00',20,'campus','draft','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(19,5,41,'Seminar Nasional Teknologi Kampus Demo Banda Aceh','Seminar Nasional Teknologi yang diselenggarakan di Kampus Demo Banda Aceh. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','seminar','Ruang Seminar','2026-11-27','09:00:00','12:00:00',100,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(20,5,43,'Workshop Pengembangan Aplikasi Web Kampus Demo Banda Aceh','Workshop Pengembangan Aplikasi Web yang diselenggarakan di Kampus Demo Banda Aceh. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','workshop','Laboratorium Komputer','2026-12-01','08:30:00','15:00:00',40,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(21,5,41,'Pelatihan Kepemimpinan Mahasiswa Kampus Demo Banda Aceh','Pelatihan Kepemimpinan Mahasiswa yang diselenggarakan di Kampus Demo Banda Aceh. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','pelatihan','Aula Kampus','2026-11-24','08:00:00','16:00:00',30,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(22,5,41,'Lomba Karya Tulis Ilmiah Kampus Demo Banda Aceh','Lomba Karya Tulis Ilmiah yang diselenggarakan di Kampus Demo Banda Aceh. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lomba','Gedung Rektorat','2026-12-08','09:00:00','14:00:00',60,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(23,5,43,'Bakti Sosial Mahasiswa Kampus Demo Banda Aceh','Bakti Sosial Mahasiswa yang diselenggarakan di Kampus Demo Banda Aceh. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','bakti_sosial','Desa Binaan','2026-11-12','07:30:00','12:00:00',25,'campus','completed','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(24,5,41,'Rapat Kerja Organisasi Kampus Demo Banda Aceh','Rapat Kerja Organisasi yang diselenggarakan di Kampus Demo Banda Aceh. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lainnya','Ruang Rapat','2026-12-17','13:00:00','16:00:00',20,'campus','draft','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(25,6,46,'Seminar Nasional Teknologi Kampus Demo Aceh Besar','Seminar Nasional Teknologi yang diselenggarakan di Kampus Demo Aceh Besar. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','seminar','Ruang Seminar','2026-11-27','09:00:00','12:00:00',100,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(26,6,48,'Workshop Pengembangan Aplikasi Web Kampus Demo Aceh Besar','Workshop Pengembangan Aplikasi Web yang diselenggarakan di Kampus Demo Aceh Besar. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','workshop','Laboratorium Komputer','2026-12-01','08:30:00','15:00:00',40,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(27,6,46,'Pelatihan Kepemimpinan Mahasiswa Kampus Demo Aceh Besar','Pelatihan Kepemimpinan Mahasiswa yang diselenggarakan di Kampus Demo Aceh Besar. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','pelatihan','Aula Kampus','2026-11-24','08:00:00','16:00:00',30,'campus','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(28,6,46,'Lomba Karya Tulis Ilmiah Kampus Demo Aceh Besar','Lomba Karya Tulis Ilmiah yang diselenggarakan di Kampus Demo Aceh Besar. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lomba','Gedung Rektorat','2026-12-08','09:00:00','14:00:00',60,'public','published','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(29,6,48,'Bakti Sosial Mahasiswa Kampus Demo Aceh Besar','Bakti Sosial Mahasiswa yang diselenggarakan di Kampus Demo Aceh Besar. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','bakti_sosial','Desa Binaan','2026-11-12','07:30:00','12:00:00',25,'campus','completed','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(30,6,46,'Rapat Kerja Organisasi Kampus Demo Aceh Besar','Rapat Kerja Organisasi yang diselenggarakan di Kampus Demo Aceh Besar. Terbuka untuk mahasiswa. (Data demo SIPAFIK)','lainnya','Ruang Rapat','2026-12-17','13:00:00','16:00:00',20,'campus','draft','2026-11-17 05:47:00','2026-11-17 05:47:00');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facility_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `facility_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campus_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `laboratory_id` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `purpose` text NOT NULL,
  `request_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `participants_count` int(10) unsigned NOT NULL DEFAULT 1,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `review_notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facility_requests_approved_by_foreign` (`approved_by`),
  KEY `facility_requests_laboratory_id_request_date_status_index` (`laboratory_id`,`request_date`,`status`),
  KEY `facility_requests_user_id_status_index` (`user_id`,`status`),
  KEY `facility_requests_campus_id_foreign` (`campus_id`),
  CONSTRAINT `facility_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `facility_requests_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `facility_requests_laboratory_id_foreign` FOREIGN KEY (`laboratory_id`) REFERENCES `laboratories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `facility_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `facility_requests` WRITE;
/*!40000 ALTER TABLE `facility_requests` DISABLE KEYS */;
INSERT INTO `facility_requests` VALUES
(1,NULL,1,1,3,'Pengajuan Praktikum Tambahan','Praktikum tambahan mata kuliah Pemrograman Web.','2026-11-03','13:00:00','15:00:00',25,'approved','Pengajuan disetujui. Silakan menggunakan laboratorium sesuai jadwal.','2026-10-31 05:42:04','2026-10-31 05:48:38'),
(2,NULL,1,1,4,'Pengajuan Penggunaan Laboratorium','Pengujian proses persetujuan oleh Admin.','2026-11-05','13:00:00','15:00:00',20,'approved','Pengajuan disetujui oleh Admin untuk penggunaan laboratorium.','2026-10-31 06:02:08','2026-10-31 06:03:41'),
(3,2,29,3,27,'Latihan Tim Lomba Pemrograman','Persiapan lomba pemrograman tingkat provinsi.','2026-11-19','13:00:00','15:00:00',20,'approved','Disetujui. Harap menjaga kebersihan ruangan.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(4,2,28,4,71,'Pelatihan Dasar Jaringan','Pelatihan jaringan untuk mahasiswa semester awal.','2026-11-20','13:00:00','15:00:00',20,'approved','Disetujui oleh Admin Kampus.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(5,2,26,5,NULL,'Seminar Teknologi Kampus','Seminar terbuka yang diselenggarakan organisasi.','2026-11-23','09:00:00','12:00:00',50,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(6,2,30,3,NULL,'Belajar Kelompok Basis Data','Belajar kelompok menjelang ujian.','2026-11-24','13:00:00','15:00:00',15,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(7,2,29,4,27,'Uji Coba Server Pribadi','Eksperimen konfigurasi server di luar jam kuliah.','2026-11-21','13:00:00','14:00:00',10,'rejected','Ditolak: laboratorium dijadwalkan untuk pemeliharaan perangkat.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(8,3,34,7,32,'Latihan Tim Lomba Pemrograman','Persiapan lomba pemrograman tingkat provinsi.','2026-11-19','13:00:00','15:00:00',20,'approved','Disetujui. Harap menjaga kebersihan ruangan.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(9,3,33,8,72,'Pelatihan Dasar Jaringan','Pelatihan jaringan untuk mahasiswa semester awal.','2026-11-20','13:00:00','15:00:00',20,'approved','Disetujui oleh Admin Kampus.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(10,3,31,9,NULL,'Seminar Teknologi Kampus','Seminar terbuka yang diselenggarakan organisasi.','2026-11-23','09:00:00','12:00:00',50,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(11,3,35,7,NULL,'Belajar Kelompok Basis Data','Belajar kelompok menjelang ujian.','2026-11-24','13:00:00','15:00:00',15,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(12,3,34,8,32,'Uji Coba Server Pribadi','Eksperimen konfigurasi server di luar jam kuliah.','2026-11-21','13:00:00','14:00:00',10,'rejected','Ditolak: laboratorium dijadwalkan untuk pemeliharaan perangkat.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(13,4,39,11,37,'Latihan Tim Lomba Pemrograman','Persiapan lomba pemrograman tingkat provinsi.','2026-11-19','13:00:00','15:00:00',20,'approved','Disetujui. Harap menjaga kebersihan ruangan.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(14,4,38,12,73,'Pelatihan Dasar Jaringan','Pelatihan jaringan untuk mahasiswa semester awal.','2026-11-20','13:00:00','15:00:00',20,'approved','Disetujui oleh Admin Kampus.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(15,4,36,13,NULL,'Seminar Teknologi Kampus','Seminar terbuka yang diselenggarakan organisasi.','2026-11-23','09:00:00','12:00:00',50,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(16,4,40,11,NULL,'Belajar Kelompok Basis Data','Belajar kelompok menjelang ujian.','2026-11-24','13:00:00','15:00:00',15,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(17,4,39,12,37,'Uji Coba Server Pribadi','Eksperimen konfigurasi server di luar jam kuliah.','2026-11-21','13:00:00','14:00:00',10,'rejected','Ditolak: laboratorium dijadwalkan untuk pemeliharaan perangkat.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(18,5,44,15,42,'Latihan Tim Lomba Pemrograman','Persiapan lomba pemrograman tingkat provinsi.','2026-11-19','13:00:00','15:00:00',20,'approved','Disetujui. Harap menjaga kebersihan ruangan.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(19,5,43,16,74,'Pelatihan Dasar Jaringan','Pelatihan jaringan untuk mahasiswa semester awal.','2026-11-20','13:00:00','15:00:00',20,'approved','Disetujui oleh Admin Kampus.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(20,5,41,17,NULL,'Seminar Teknologi Kampus','Seminar terbuka yang diselenggarakan organisasi.','2026-11-23','09:00:00','12:00:00',50,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(21,5,45,15,NULL,'Belajar Kelompok Basis Data','Belajar kelompok menjelang ujian.','2026-11-24','13:00:00','15:00:00',15,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(22,5,44,16,42,'Uji Coba Server Pribadi','Eksperimen konfigurasi server di luar jam kuliah.','2026-11-21','13:00:00','14:00:00',10,'rejected','Ditolak: laboratorium dijadwalkan untuk pemeliharaan perangkat.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(23,6,49,19,47,'Latihan Tim Lomba Pemrograman','Persiapan lomba pemrograman tingkat provinsi.','2026-11-19','13:00:00','15:00:00',20,'approved','Disetujui. Harap menjaga kebersihan ruangan.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(24,6,48,20,75,'Pelatihan Dasar Jaringan','Pelatihan jaringan untuk mahasiswa semester awal.','2026-11-20','13:00:00','15:00:00',20,'approved','Disetujui oleh Admin Kampus.','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(25,6,46,21,NULL,'Seminar Teknologi Kampus','Seminar terbuka yang diselenggarakan organisasi.','2026-11-23','09:00:00','12:00:00',50,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(26,6,50,19,NULL,'Belajar Kelompok Basis Data','Belajar kelompok menjelang ujian.','2026-11-24','13:00:00','15:00:00',15,'pending',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00'),
(27,6,49,20,47,'Uji Coba Server Pribadi','Eksperimen konfigurasi server di luar jam kuliah.','2026-11-21','13:00:00','14:00:00',10,'rejected','Ditolak: laboratorium dijadwalkan untuk pemeliharaan perangkat.','2026-11-17 05:47:00','2026-11-17 05:47:00');
/*!40000 ALTER TABLE `facility_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` varchar(255) NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` smallint(5) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `lab_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lab_schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campus_id` bigint(20) unsigned DEFAULT NULL,
  `laboratory_id` bigint(20) unsigned NOT NULL,
  `lecturer_id` bigint(20) unsigned DEFAULT NULL,
  `course_name` varchar(255) NOT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `schedule_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `schedule_type` varchar(30) NOT NULL DEFAULT 'praktikum',
  `status` varchar(20) NOT NULL DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lab_schedules_lecturer_id_foreign` (`lecturer_id`),
  KEY `lab_schedules_laboratory_id_schedule_date_index` (`laboratory_id`,`schedule_date`),
  KEY `lab_schedules_campus_id_foreign` (`campus_id`),
  CONSTRAINT `lab_schedules_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `lab_schedules_laboratory_id_foreign` FOREIGN KEY (`laboratory_id`) REFERENCES `laboratories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `lab_schedules_lecturer_id_foreign` FOREIGN KEY (`lecturer_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `lab_schedules` WRITE;
/*!40000 ALTER TABLE `lab_schedules` DISABLE KEYS */;
INSERT INTO `lab_schedules` VALUES
(1,NULL,1,2,'Pemrograman Web','TI-5A','2026-11-02','08:00:00','10:00:00','praktikum','scheduled','Praktikum Pemrograman Web','2026-10-31 05:08:46','2026-10-31 05:08:46'),
(2,2,3,28,'Pemrograman Web','TI-5A','2026-11-18','08:00:00','10:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(3,2,3,28,'Basis Data','TI-3B','2026-11-19','10:30:00','12:30:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(4,2,4,28,'Jaringan Komputer','TI-5B','2026-11-20','08:00:00','11:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(5,2,5,28,'Seminar Proposal','TI-7A','2026-11-21','09:00:00','11:00:00','kegiatan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(6,2,4,28,'Keamanan Informasi','TI-7B','2026-11-22','08:00:00','10:00:00','perkuliahan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(7,3,7,33,'Pemrograman Web','TI-5A','2026-11-18','08:00:00','10:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(8,3,7,33,'Basis Data','TI-3B','2026-11-19','10:30:00','12:30:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(9,3,8,33,'Jaringan Komputer','TI-5B','2026-11-20','08:00:00','11:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(10,3,9,33,'Seminar Proposal','TI-7A','2026-11-21','09:00:00','11:00:00','kegiatan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(11,3,8,33,'Keamanan Informasi','TI-7B','2026-11-22','08:00:00','10:00:00','perkuliahan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(12,4,11,38,'Pemrograman Web','TI-5A','2026-11-18','08:00:00','10:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(13,4,11,38,'Basis Data','TI-3B','2026-11-19','10:30:00','12:30:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(14,4,12,38,'Jaringan Komputer','TI-5B','2026-11-20','08:00:00','11:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(15,4,13,38,'Seminar Proposal','TI-7A','2026-11-21','09:00:00','11:00:00','kegiatan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(16,4,12,38,'Keamanan Informasi','TI-7B','2026-11-22','08:00:00','10:00:00','perkuliahan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(17,5,15,43,'Pemrograman Web','TI-5A','2026-11-18','08:00:00','10:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(18,5,15,43,'Basis Data','TI-3B','2026-11-19','10:30:00','12:30:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(19,5,16,43,'Jaringan Komputer','TI-5B','2026-11-20','08:00:00','11:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(20,5,17,43,'Seminar Proposal','TI-7A','2026-11-21','09:00:00','11:00:00','kegiatan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(21,5,16,43,'Keamanan Informasi','TI-7B','2026-11-22','08:00:00','10:00:00','perkuliahan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(22,6,19,48,'Pemrograman Web','TI-5A','2026-11-18','08:00:00','10:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(23,6,19,48,'Basis Data','TI-3B','2026-11-19','10:30:00','12:30:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(24,6,20,48,'Jaringan Komputer','TI-5B','2026-11-20','08:00:00','11:00:00','praktikum','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(25,6,21,48,'Seminar Proposal','TI-7A','2026-11-21','09:00:00','11:00:00','kegiatan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(26,6,20,48,'Keamanan Informasi','TI-7B','2026-11-22','08:00:00','10:00:00','perkuliahan','scheduled','Data demo SIPAFIK','2026-11-17 05:47:00','2026-11-17 05:47:00');
/*!40000 ALTER TABLE `lab_schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `laboratories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `laboratories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `campus_id` bigint(20) unsigned DEFAULT NULL,
  `code` varchar(30) NOT NULL,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `capacity` int(10) unsigned NOT NULL DEFAULT 0,
  `facilities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`facilities`)),
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `laboratories_campus_code_unique` (`campus_id`,`code`),
  KEY `laboratories_campus_id_foreign` (`campus_id`),
  CONSTRAINT `laboratories_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `laboratories` WRITE;
/*!40000 ALTER TABLE `laboratories` DISABLE KEYS */;
INSERT INTO `laboratories` VALUES
(1,NULL,'LAB-001','Laboratorium Komputer 1','Gedung Fakultas Teknik','Laboratorium komputer untuk kegiatan praktikum mahasiswa.',30,'[\"Komputer\", \"Proyektor\", \"AC\", \"WiFi\"]','active','2026-10-31 05:05:47','2026-10-31 05:05:47'),
(2,2,'LAB-UTARA-01','Laboratorium Komputer Kampus','Gedung Laboratorium','Laboratorium untuk praktikum dan pembelajaran mahasiswa',30,'[\"Komputer\", \"Proyektor\", \"AC\", \"WiFi\"]','active','2026-11-15 22:35:10','2026-11-15 22:35:10'),
(3,2,'LAB-02-01','Laboratorium Komputer','Gedung Teknik Lt. 1','Laboratorium Komputer Kampus Demo Aceh Utara.',30,'[\"Komputer\",\"Proyektor\",\"AC\",\"WiFi\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(4,2,'LAB-02-02','Laboratorium Jaringan','Gedung Teknik Lt. 2','Laboratorium Jaringan Kampus Demo Aceh Utara.',25,'[\"Router\",\"Switch\",\"Server\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(5,2,'LAB-02-03','Ruang Seminar','Gedung Rektorat Lt. 3','Ruang Seminar Kampus Demo Aceh Utara.',60,'[\"Proyektor\",\"Sound System\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(6,2,'LAB-02-04','Laboratorium Multimedia','Gedung Seni Lt. 1','Laboratorium Multimedia Kampus Demo Aceh Utara.',20,'[\"Komputer Grafis\",\"Kamera\",\"Studio Mini\"]','inactive','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(7,3,'LAB-03-01','Laboratorium Komputer','Gedung Teknik Lt. 1','Laboratorium Komputer Kampus Demo Pidie Jaya.',30,'[\"Komputer\",\"Proyektor\",\"AC\",\"WiFi\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(8,3,'LAB-03-02','Laboratorium Jaringan','Gedung Teknik Lt. 2','Laboratorium Jaringan Kampus Demo Pidie Jaya.',25,'[\"Router\",\"Switch\",\"Server\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(9,3,'LAB-03-03','Ruang Seminar','Gedung Rektorat Lt. 3','Ruang Seminar Kampus Demo Pidie Jaya.',60,'[\"Proyektor\",\"Sound System\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(10,3,'LAB-03-04','Laboratorium Multimedia','Gedung Seni Lt. 1','Laboratorium Multimedia Kampus Demo Pidie Jaya.',20,'[\"Komputer Grafis\",\"Kamera\",\"Studio Mini\"]','inactive','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(11,4,'LAB-04-01','Laboratorium Komputer','Gedung Teknik Lt. 1','Laboratorium Komputer Kampus Demo Bireuen.',30,'[\"Komputer\",\"Proyektor\",\"AC\",\"WiFi\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(12,4,'LAB-04-02','Laboratorium Jaringan','Gedung Teknik Lt. 2','Laboratorium Jaringan Kampus Demo Bireuen.',25,'[\"Router\",\"Switch\",\"Server\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(13,4,'LAB-04-03','Ruang Seminar','Gedung Rektorat Lt. 3','Ruang Seminar Kampus Demo Bireuen.',60,'[\"Proyektor\",\"Sound System\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(14,4,'LAB-04-04','Laboratorium Multimedia','Gedung Seni Lt. 1','Laboratorium Multimedia Kampus Demo Bireuen.',20,'[\"Komputer Grafis\",\"Kamera\",\"Studio Mini\"]','inactive','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(15,5,'LAB-05-01','Laboratorium Komputer','Gedung Teknik Lt. 1','Laboratorium Komputer Kampus Demo Banda Aceh.',30,'[\"Komputer\",\"Proyektor\",\"AC\",\"WiFi\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(16,5,'LAB-05-02','Laboratorium Jaringan','Gedung Teknik Lt. 2','Laboratorium Jaringan Kampus Demo Banda Aceh.',25,'[\"Router\",\"Switch\",\"Server\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(17,5,'LAB-05-03','Ruang Seminar','Gedung Rektorat Lt. 3','Ruang Seminar Kampus Demo Banda Aceh.',60,'[\"Proyektor\",\"Sound System\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(18,5,'LAB-05-04','Laboratorium Multimedia','Gedung Seni Lt. 1','Laboratorium Multimedia Kampus Demo Banda Aceh.',20,'[\"Komputer Grafis\",\"Kamera\",\"Studio Mini\"]','inactive','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(19,6,'LAB-06-01','Laboratorium Komputer','Gedung Teknik Lt. 1','Laboratorium Komputer Kampus Demo Aceh Besar.',30,'[\"Komputer\",\"Proyektor\",\"AC\",\"WiFi\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(20,6,'LAB-06-02','Laboratorium Jaringan','Gedung Teknik Lt. 2','Laboratorium Jaringan Kampus Demo Aceh Besar.',25,'[\"Router\",\"Switch\",\"Server\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(21,6,'LAB-06-03','Ruang Seminar','Gedung Rektorat Lt. 3','Ruang Seminar Kampus Demo Aceh Besar.',60,'[\"Proyektor\",\"Sound System\",\"AC\"]','active','2026-11-17 05:47:00','2026-11-17 05:47:00'),
(22,6,'LAB-06-04','Laboratorium Multimedia','Gedung Seni Lt. 1','Laboratorium Multimedia Kampus Demo Aceh Besar.',20,'[\"Komputer Grafis\",\"Kamera\",\"Studio Mini\"]','inactive','2026-11-17 05:47:00','2026-11-17 05:47:00');
/*!40000 ALTER TABLE `laboratories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_10_31_065805_add_role_to_users_table',1),
(5,'2026_10_31_065806_create_laboratories_table',1),
(6,'2026_10_31_065807_create_lab_schedules_table',1),
(7,'2026_10_31_065808_create_facility_requests_table',1),
(8,'2026_10_31_072101_create_personal_access_tokens_table',2),
(9,'2026_11_06_034700_create_campuses_table',3),
(10,'2026_11_06_035029_add_campus_fields_to_users_table',4),
(11,'2026_11_06_042322_add_is_active_to_users_table',5),
(12,'2026_11_16_014342_add_campus_id_to_facility_tables',6),
(13,'2026_11_16_100000_create_events_table',7),
(14,'2026_11_16_100100_create_event_registrations_table',7),
(15,'2026_11_16_100200_make_laboratory_code_unique_per_campus',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES
(1,'App\\Models\\User',1,'sipafik-token','a7ac2eed6cf889f9e334883be061f9e6f457f9668a25597707ee03a9beeb5adb','[\"*\"]','2026-10-31 05:42:04',NULL,'2026-10-31 05:32:05','2026-10-31 05:42:04'),
(2,'App\\Models\\User',3,'sipafik-token','ff41c5aaa297867368cab139fc368830926678ef8731fa1471433834ef5c53f1','[\"*\"]','2026-10-31 05:48:38',NULL,'2026-10-31 05:44:42','2026-10-31 05:48:38'),
(3,'App\\Models\\User',1,'sipafik-token','55d0cfcd6893a51e03fae9989a75280d38151224bc090285714a4833c216fe5f','[\"*\"]','2026-10-31 06:02:08',NULL,'2026-10-31 05:49:35','2026-10-31 06:02:08'),
(5,'App\\Models\\User',4,'sipafik-token','79d16c31a7da3d60d130f2b0a0e54b785190698a755af2690ac439e71d7dc387','[\"*\"]',NULL,NULL,'2026-10-31 06:13:49','2026-10-31 06:13:49'),
(6,'App\\Models\\User',2,'sipafik-token','ff01e87fc87e920673c3d152835c390fff871a3747b77793338c49c81ba1ccb0','[\"*\"]','2026-10-31 06:15:41',NULL,'2026-10-31 06:14:43','2026-10-31 06:15:41');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('iUaJsKrqiv6pqz57vPLSSt64SgUlAPt4tBZja7dS',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36 Edg/157.0.0.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiT3VnWUIweVZRQkJGT2hGa1pjM043M1d3QnpxdkFlWHo3TjZ3RjdLRyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1794710927),
('l2ubgD2RWiH3HDzUcvEmD5PMeLckrZki8xsx7gF2',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36 Edg/157.0.0.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiR1VLUllRNlJKMkZiWWR1SnlQQWNtVmtsYlQ1M0RkeUpldFNzSk9sMiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0MToiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2NhbXB1cy9sYWJvcmF0b3JpZXMiO31zOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czo0MToiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2NhbXB1cy9sYWJvcmF0b3JpZXMiO3M6NToicm91dGUiO3M6MjU6ImNhbXB1cy5sYWJvcmF0b3JpZXMuaW5kZXgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1794806879),
('X04CNR1bqkoVhEA7hQUmjyc7PTqR3elKjrlG7nRm',7,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36 Edg/157.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSDJmVjlOZnc0Uno5Yml2bjJ0YVptTFdSYjkzaVdVNjJmZFprOHRDNyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNoYm9hcmQiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NztzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2NDoiY2FiZjM3ZmJiY2Y4MGJmZWJjYmY1MmQyZjc4MGM0ZWNmN2ViYzNjNDkwMWYwMTI5NGY4ZGQzODQ0NDIzZWM2OSI7fQ==',1794716442),
('zLYkeCesF4AxLKS2uMhPZqT5vX1MsGSbVNipLe4X',27,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Safari/537.36 Edg/157.0.0.0','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiZHpVeXlFRWVGZkxuZnNzcmVpbDBka3k3Q0Z0NFJVNFFUT3JkendKWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9jYW1wdXMvbGFib3JhdG9yaWVzIjtzOjU6InJvdXRlIjtzOjI1OiJjYW1wdXMubGFib3JhdG9yaWVzLmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6Mjc7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjQ6ImM1OGI0ZjlhMGI4NTQ4MjA1ZTdjMjYwOGNlNmZkMjg5N2JhOTY3MGIyZmZlMzgzZGM4NTFiNzlhM2EzYmJmOTciO30=',1794807310);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(30) NOT NULL DEFAULT 'mahasiswa',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `campus_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_campus_id_foreign` (`campus_id`),
  CONSTRAINT `users_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Mahasiswa SIPAFIK','mahasiswa@sipafik.test',NULL,'$2y$12$y8/8uO5hjIFfBYWEjIderOeShmYk4R7NwNgvvAfSz89RqCaYyEY9q','mahasiswa',NULL,'2026-10-31 05:06:50','2026-10-31 05:06:50',NULL,'user_1',1),
(2,'Dosen SIPAFIK','dosen@sipafik.test',NULL,'$2y$12$xjvmkgXNR1O5WEGYHlN1/eeV.RTpcjO8qj8GbMo3PxUu.lw5F6sua','dosen',NULL,'2026-10-31 05:07:02','2026-10-31 05:07:02',NULL,'user_2',1),
(3,'Petugas Laboratorium','petugas@sipafik.test',NULL,'$2y$12$79/VfgCjQqprv0GNLO8otOawzFh4ANU5ea6LcRNvOd7ha0qMkZCnG','petugas_laboratorium',NULL,'2026-10-31 05:07:48','2026-10-31 05:07:48',NULL,'user_3',1),
(4,'Admin SIPAFIK','admin@sipafik.test',NULL,'$2y$12$JLzS./p79P2HRjDSfEqUX.wWukneyXdamRoMaq.PdMK/xdtRwUN/.','admin',NULL,'2026-10-31 05:08:04','2026-10-31 05:08:04',NULL,'user_4',1),
(5,'Admin UNIGHA','admin@unigha.ac.id',NULL,'$2y$12$ibpq6ZM2UIS5pi0twlj6yeRGYZ2hlTZ0vsoM4JslZsYzByvMwPVGm','admin_kampus',NULL,'2026-11-05 21:20:50','2026-11-05 21:20:50',1,'unigha',0),
(6,'Super Admin SIPAFIK','superadmin@sipafik.test',NULL,'$2y$12$X4OmTiZ.W8m6Mnj9EVca8OJ6lbG6/9Y.LsOAQG7oLHDLGGAXaFoSe','super_admin',NULL,'2026-11-05 21:28:20','2026-11-05 21:28:20',NULL,'superadmin',1),
(7,'Tatia Alza','tatia.alza.demo@sipafik.test',NULL,'$2y$12$Re5vhU/lBxGSspH5f8b8j.nM0gcYFt1MYeMniejgfb62ptYjISPKu','mahasiswa',NULL,'2026-11-14 19:20:35','2026-11-14 19:20:35',1,'tatia_demo',1),
(8,'Cipa','cipa.demo@sipafik.test',NULL,'$2y$12$2KoTUUQhceit6U2D09N4VOWlsnejNhFajboP8KQHcyxP0u/H3/rL.','mahasiswa',NULL,'2026-11-14 19:20:36','2026-11-14 19:20:36',1,'cipa_demo',1),
(9,'Aulia Putri','aulia.demo@sipafik.test',NULL,'$2y$12$.0GT4NIIBgNy7RhIg7Xc9ObDjPVEGI0lLhcwzTjIrlCy85CGi1gV2','mahasiswa',NULL,'2026-11-14 19:20:36','2026-11-14 19:20:36',1,'aulia_demo',1),
(10,'Nabila Zahra','nabila.demo@sipafik.test',NULL,'$2y$12$.9txFfGTSXzeFbaA211cCuhUpSu0Gfj4L0LEWUNSvWDwUz5pe71Pq','mahasiswa',NULL,'2026-11-14 19:20:37','2026-11-14 19:20:37',1,'nabila_demo',1),
(11,'Rani Safitri','rani.demo@sipafik.test',NULL,'$2y$12$dbAOUSsYHXB8lltTktzDrO76QTtjNLkZe6e6g639SYlTYZFu.wxx6','mahasiswa',NULL,'2026-11-14 19:20:37','2026-11-14 19:20:37',1,'rani_demo',1),
(12,'Dinda Amelia','dinda.demo@sipafik.test',NULL,'$2y$12$cjjD3DS143qDULW7sdDD7exLRr/.GjLgvmmA4S3G3c6uUZ3qMVp6i','mahasiswa',NULL,'2026-11-14 19:20:38','2026-11-14 19:20:38',1,'dinda_demo',1),
(13,'Fajar Ramadhan','fajar.demo@sipafik.test',NULL,'$2y$12$W6AUCEbMDGvCfM7sn0scOebD6Bgu.q2PiGl8MmoIzeSo3WzWG/VjG','mahasiswa',NULL,'2026-11-14 19:20:38','2026-11-14 19:20:38',1,'fajar_demo',1),
(14,'Rizky Maulana','rizky.demo@sipafik.test',NULL,'$2y$12$ulxwfrqxLq7V7u0m7Htep.arzSsiY89Hu05eO2JHVNMUEYVyd584G','mahasiswa',NULL,'2026-11-14 19:20:39','2026-11-14 19:20:39',1,'rizky_demo',1),
(15,'Nadia Putri','nadia.demo@sipafik.test',NULL,'$2y$12$ROXAfZXd/p9tgfpRR188kuN4tfJiEDav2tQYjPUfEeZ5bI/7zAZ5K','mahasiswa',NULL,'2026-11-14 19:20:39','2026-11-14 19:20:39',1,'nadia_demo',1),
(16,'BEM UNIGHA','bem.demo@sipafik.test',NULL,'$2y$12$hyQyG4D0wImBoJh3vLqMn..rQ/Ql2xMyBjV2muom5S5sJhO.me/3m','organisasi',NULL,'2026-11-14 19:20:40','2026-11-14 19:20:40',1,'bem_unigha',1),
(17,'Himpunan Teknik Informatika','hima.demo@sipafik.test',NULL,'$2y$12$EiV7Z/ycZvQ5SgJgbX1H8uRQlzL7Loaf2uReqzB/Y7/cTKNcSgCo6','organisasi',NULL,'2026-11-14 19:20:40','2026-11-14 19:20:40',1,'hima_ti',1),
(18,'Rahmat Hidayat','rahmat.demo@sipafik.test',NULL,'$2y$12$Bxy/7Lc6Wakm6O/nz/HRXOvxcSvvTfFA51NNdu2FSyxBWYjtgYgRi','dosen',NULL,'2026-11-14 19:20:41','2026-11-14 19:20:41',1,'rahmat_demo',1),
(19,'Siti Nurhaliza','siti.demo@sipafik.test',NULL,'$2y$12$oAPP2pXheqwgheJ1H/AXYeHTF/URPvXNNqMgBylenkulJfsYTQW.K','dosen',NULL,'2026-11-14 19:20:41','2026-11-14 19:20:41',1,'siti_demo',1),
(20,'Andi Saputra','andi.demo@sipafik.test',NULL,'$2y$12$u.yKw7SHd3cpdgFTu9ootuOMrRyDJ2i1.4arQmM7bXkSa6Umw8Pba','petugas_fasilitas',NULL,'2026-11-14 19:20:41','2026-11-14 19:20:41',1,'andi_demo',1),
(21,'Organisasi Demo 01','organisasi01@sipafik.test',NULL,'$2y$12$1IoycxPqwVkt.4FWsmOTn.VzCO/xe9yXxTGf0DAtM1mkKcZ/x28bi','organisasi',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48',1,'organisasi_demo_01',1),
(22,'Petugas Fasilitas 01','petugas01@sipafik.test',NULL,'$2y$12$Ztn0yPlNIVEcbDIPvx8Pq.4baPAlzuaPG9JoZykpSzisJ0onbPYZC','petugas_fasilitas',NULL,'2026-11-14 20:42:48','2026-11-14 20:42:48',1,'petugas_demo_01',1),
(23,'Dosen Demo 01','dosen01@sipafik.test',NULL,'$2y$12$08OjGT9wcEvQWD4XR3zUbeUiD6wnxqDRP/BIb.lUk/fNgveSXPpha','dosen',NULL,'2026-11-14 20:42:49','2026-11-14 20:42:49',1,'dosen_demo_01',1),
(24,'Mahasiswa Demo 01A','mahasiswa01a@sipafik.test',NULL,'$2y$12$tm8kkd0TqFgKQTTC..S6NOInVcDg0Joa0E9/FzLT0g6LYM4UzRWb6','mahasiswa',NULL,'2026-11-14 20:42:49','2026-11-14 20:42:49',1,'mahasiswa_demo_01a',1),
(25,'Mahasiswa Demo 01B','mahasiswa01b@sipafik.test',NULL,'$2y$12$SfRDwY8NpuSr84DJIDhbOONi.N/tFDDI8eLfuk4sFSjW63/Gdc2MK','mahasiswa',NULL,'2026-11-14 20:42:49','2026-11-14 20:42:49',1,'mahasiswa_demo_01b',1),
(26,'Organisasi Demo 02','organisasi02@sipafik.test',NULL,'$2y$12$knSXt.BfABGp2KElK/SqXu56nRY6h8vYF99nq0WwGyr/B25ZVacX2','organisasi',NULL,'2026-11-14 20:42:49','2026-11-14 20:42:49',2,'organisasi_demo_02',1),
(27,'Petugas Fasilitas 02','petugas02@sipafik.test',NULL,'$2y$12$YVWZDFMejMSGpno3umnW2uWYZJcqYSCeYw1U5pjU.bAM1GKj.ld.C','petugas_fasilitas',NULL,'2026-11-14 20:42:49','2026-11-14 20:42:49',2,'petugas_demo_02',1),
(28,'Dosen Demo 02','dosen02@sipafik.test',NULL,'$2y$12$VmLD4NegyNfUfVA4cfk9VekT6lyuDzvZwwpPxNpXwzO/0bl1jRY9C','dosen',NULL,'2026-11-14 20:42:50','2026-11-14 20:42:50',2,'dosen_demo_02',1),
(29,'Mahasiswa Demo 02A','mahasiswa02a@sipafik.test',NULL,'$2y$12$I1fHZH2PsK29iYJRRfa0uuMm0/Y/NsO1XF69kI3/fxXokzY7vvluW','mahasiswa',NULL,'2026-11-14 20:42:50','2026-11-14 20:42:50',2,'mahasiswa_demo_02a',1),
(30,'Mahasiswa Demo 02B','mahasiswa02b@sipafik.test',NULL,'$2y$12$Z9QG1b.QtC/RR/b/UIvfJe5ei8cosgRO5VOxxLZ42a9ecF9rGhCqO','mahasiswa',NULL,'2026-11-14 20:42:50','2026-11-14 20:42:50',2,'mahasiswa_demo_02b',1),
(31,'Organisasi Demo 03','organisasi03@sipafik.test',NULL,'$2y$12$aV.KGiUmBJZCnufvMMsQc.JfF54b21otlRk9GY/0N77.8KABwJ3u2','organisasi',NULL,'2026-11-14 20:42:50','2026-11-14 20:42:50',3,'organisasi_demo_03',1),
(32,'Petugas Fasilitas 03','petugas03@sipafik.test',NULL,'$2y$12$xhLfBeaXTu6LGgCQBjGw3OwMkicplIXJ.4QSbN29zP6bMxDqxsnHi','petugas_fasilitas',NULL,'2026-11-14 20:42:51','2026-11-14 20:42:51',3,'petugas_demo_03',1),
(33,'Dosen Demo 03','dosen03@sipafik.test',NULL,'$2y$12$I499a/YKCHBtf6CejSx0bOhpMXuA92DXRJjxzT/F1jq5oC7yB47zm','dosen',NULL,'2026-11-14 20:42:51','2026-11-14 20:42:51',3,'dosen_demo_03',1),
(34,'Mahasiswa Demo 03A','mahasiswa03a@sipafik.test',NULL,'$2y$12$ODuN77gJB5l9YBkkhoTmUuoFrJPX2R//8bRdBP8UKZeAXYhHPOinW','mahasiswa',NULL,'2026-11-14 20:42:51','2026-11-14 20:42:51',3,'mahasiswa_demo_03a',1),
(35,'Mahasiswa Demo 03B','mahasiswa03b@sipafik.test',NULL,'$2y$12$pobsF0F8OXV.GfZjFgs/9udyqMWQSuKhUgQlgxM2x46yidKDjUq1C','mahasiswa',NULL,'2026-11-14 20:42:51','2026-11-14 20:42:51',3,'mahasiswa_demo_03b',1),
(36,'Organisasi Demo 04','organisasi04@sipafik.test',NULL,'$2y$12$wlJCHdPw0t01Zoi8FWRQX.3YZlP9YdGCfI161HTJY6UGoNonjDd6y','organisasi',NULL,'2026-11-14 20:42:51','2026-11-14 20:42:51',4,'organisasi_demo_04',1),
(37,'Petugas Fasilitas 04','petugas04@sipafik.test',NULL,'$2y$12$jaqJe58AkIxOab6QNhG4aOVC0sI1tHa.n/XYSZSiAMpVciBRTcINy','petugas_fasilitas',NULL,'2026-11-14 20:42:52','2026-11-14 20:42:52',4,'petugas_demo_04',1),
(38,'Dosen Demo 04','dosen04@sipafik.test',NULL,'$2y$12$5vLpsKo8bCrxdhLgk5lE2OBM76qUo7vFlYki0Zim6vUrD7Xilvz9y','dosen',NULL,'2026-11-14 20:42:52','2026-11-14 20:42:52',4,'dosen_demo_04',1),
(39,'Mahasiswa Demo 04A','mahasiswa04a@sipafik.test',NULL,'$2y$12$WhnFaOhxOLfNRaKZqLv1le6iiZ0rwU.nnw/xYOtQH2pJN9WFmcIc6','mahasiswa',NULL,'2026-11-14 20:42:52','2026-11-14 20:42:52',4,'mahasiswa_demo_04a',1),
(40,'Mahasiswa Demo 04B','mahasiswa04b@sipafik.test',NULL,'$2y$12$tY8kPQ9BzMclzWbK.koX1O7M7FKidwKu3BxVfaeHnDkQ7RJ1XnUFi','mahasiswa',NULL,'2026-11-14 20:42:52','2026-11-14 20:42:52',4,'mahasiswa_demo_04b',1),
(41,'Organisasi Demo 05','organisasi05@sipafik.test',NULL,'$2y$12$4y6e8YA.CbhC7tbC5fGMxujUC0dL9mcQC3Huxq5zbVR493kFuY3ry','organisasi',NULL,'2026-11-14 20:42:52','2026-11-14 20:42:52',5,'organisasi_demo_05',1),
(42,'Petugas Fasilitas 05','petugas05@sipafik.test',NULL,'$2y$12$jCIC8Sm3oXd/7h9RLhuvV.VhAyWevwwQEv5mYB7a.3P/Xf4lKnJ.u','petugas_fasilitas',NULL,'2026-11-14 20:42:53','2026-11-14 20:42:53',5,'petugas_demo_05',1),
(43,'Dosen Demo 05','dosen05@sipafik.test',NULL,'$2y$12$PWbowD7IBcNtXnlJxoxDI.97p1vWlD/1K2rXyaxrx3Ndc6G3z0X5u','dosen',NULL,'2026-11-14 20:42:53','2026-11-14 20:42:53',5,'dosen_demo_05',1),
(44,'Mahasiswa Demo 05A','mahasiswa05a@sipafik.test',NULL,'$2y$12$VHZWzjPCEIEKcJCipgfgSua9/IV83y5volWO6IrHXxP4SscZO9KqW','mahasiswa',NULL,'2026-11-14 20:42:53','2026-11-14 20:42:53',5,'mahasiswa_demo_05a',1),
(45,'Mahasiswa Demo 05B','mahasiswa05b@sipafik.test',NULL,'$2y$12$20ZKyzFcryNoBsSLdAbvH.qcImFUiy3rPMNs2/rTKX5kWJJlKIYAu','mahasiswa',NULL,'2026-11-14 20:42:53','2026-11-14 20:42:53',5,'mahasiswa_demo_05b',1),
(46,'Organisasi Demo 06','organisasi06@sipafik.test',NULL,'$2y$12$p4qeeH.3U3FmJCuThUtKS./XaBglYgXOWeo8eb3PKFkOTTlUEvZki','organisasi',NULL,'2026-11-14 20:42:53','2026-11-14 20:42:53',6,'organisasi_demo_06',1),
(47,'Petugas Fasilitas 06','petugas06@sipafik.test',NULL,'$2y$12$7IFWe9CR.jyjIaDD.QoGFOcebEhVISVE82RTtEdFIUuFaSsk7hJgS','petugas_fasilitas',NULL,'2026-11-14 20:42:54','2026-11-14 20:42:54',6,'petugas_demo_06',1),
(48,'Dosen Demo 06','dosen06@sipafik.test',NULL,'$2y$12$UURv880uevwXSVaeXm35ZuXbLVChpj8nprH9JVzqyROWE0QzNlJ0W','dosen',NULL,'2026-11-14 20:42:54','2026-11-14 20:42:54',6,'dosen_demo_06',1),
(49,'Mahasiswa Demo 06A','mahasiswa06a@sipafik.test',NULL,'$2y$12$tZTUZXG0E60UBk8ooSMiu./FAMleZcTLPaanSbs7yrsHoKkypGRT.','mahasiswa',NULL,'2026-11-14 20:42:54','2026-11-14 20:42:54',6,'mahasiswa_demo_06a',1),
(50,'Mahasiswa Demo 06B','mahasiswa06b@sipafik.test',NULL,'$2y$12$A4F9WwW5mmbHAfxy9T4tGuC26audbMPMdnSEQjMyV5jQuMpeNU3/K','mahasiswa',NULL,'2026-11-14 20:42:54','2026-11-14 20:42:54',6,'mahasiswa_demo_06b',1),
(51,'Organisasi Demo 07','organisasi07@sipafik.test',NULL,'$2y$12$BW08l3Ol4q8PC/S6hnaaW.D6.Xr20O9JG2kpXK1jalmSTNkLZhery','organisasi',NULL,'2026-11-14 20:42:55','2026-11-14 20:42:55',7,'organisasi_demo_07',1),
(52,'Petugas Fasilitas 07','petugas07@sipafik.test',NULL,'$2y$12$CZWtgBaHx.1lbZqp5bNG9eVFpqazgyTqgxx6GFQCH.Y/Ra/vVfJKK','petugas_fasilitas',NULL,'2026-11-14 20:42:55','2026-11-14 20:42:55',7,'petugas_demo_07',1),
(53,'Dosen Demo 07','dosen07@sipafik.test',NULL,'$2y$12$DqTjgAr1iT05I4arD5oWQOgW/L/wIgOVUjFyjaGljtdq3ZqVsQRby','dosen',NULL,'2026-11-14 20:42:55','2026-11-14 20:42:55',7,'dosen_demo_07',1),
(54,'Mahasiswa Demo 07A','mahasiswa07a@sipafik.test',NULL,'$2y$12$.cbjwVf2ZBF44ZBUh0RhSu8dSHBxJXqI5YOOnnW/4q1S2FTSnJunO','mahasiswa',NULL,'2026-11-14 20:42:55','2026-11-14 20:42:55',7,'mahasiswa_demo_07a',1),
(55,'Mahasiswa Demo 07B','mahasiswa07b@sipafik.test',NULL,'$2y$12$MaJMU5mBR63nResRyr6KluOBmhou7X/7VclV5qasBTnIZxueO.iiu','mahasiswa',NULL,'2026-11-14 20:42:55','2026-11-14 20:42:55',7,'mahasiswa_demo_07b',1),
(56,'Organisasi Demo 08','organisasi08@sipafik.test',NULL,'$2y$12$MeZy3eY9LUUMFlP3TRCHwubpAzfvhatOjPo.uZm3Ampc3lAH0cPIa','organisasi',NULL,'2026-11-14 20:42:56','2026-11-14 20:42:56',8,'organisasi_demo_08',1),
(57,'Petugas Fasilitas 08','petugas08@sipafik.test',NULL,'$2y$12$cvfiEDOLrJ6/ZjmhhFpmxOcMjQcq8zbQi.Pg9giVsq1NVo10VZUOi','petugas_fasilitas',NULL,'2026-11-14 20:42:56','2026-11-14 20:42:56',8,'petugas_demo_08',1),
(58,'Dosen Demo 08','dosen08@sipafik.test',NULL,'$2y$12$gcU0wSyFWii2Bg8aKSQIVeFW4XUM2RRhVE./bTpQ3UtB08wwcajEG','dosen',NULL,'2026-11-14 20:42:56','2026-11-14 20:42:56',8,'dosen_demo_08',1),
(59,'Mahasiswa Demo 08A','mahasiswa08a@sipafik.test',NULL,'$2y$12$BQiFXA41NZ6OfYWdITBeNuAMNpaabc1oMBBLecDTX6aPuuyBHWEa6','mahasiswa',NULL,'2026-11-14 20:42:56','2026-11-14 20:42:56',8,'mahasiswa_demo_08a',1),
(60,'Mahasiswa Demo 08B','mahasiswa08b@sipafik.test',NULL,'$2y$12$sLN3fmA9rJrH/SJOJshmReKadl6QTEinHQf9R5eH/q9bujk4UH2DG','mahasiswa',NULL,'2026-11-14 20:42:56','2026-11-14 20:42:56',8,'mahasiswa_demo_08b',1),
(61,'Organisasi Demo 09','organisasi09@sipafik.test',NULL,'$2y$12$Cr6oSX0DbN1Ip8opGiAG0.0lUT2ts0lPrvBLJbiBnpSM6nNxQF4.C','organisasi',NULL,'2026-11-14 20:42:57','2026-11-14 20:42:57',9,'organisasi_demo_09',1),
(62,'Petugas Fasilitas 09','petugas09@sipafik.test',NULL,'$2y$12$TLZYtzkYFCTAqyG2p9H4VeY4PsjEmzngAD4S3vPIgY61AVQxfQy4u','petugas_fasilitas',NULL,'2026-11-14 20:42:57','2026-11-14 20:42:57',9,'petugas_demo_09',1),
(63,'Dosen Demo 09','dosen09@sipafik.test',NULL,'$2y$12$blqlnFK54p8pdPuB3FWuauRvG5nQMXWs8wambTE2OKtoBnn40ajbS','dosen',NULL,'2026-11-14 20:42:57','2026-11-14 20:42:57',9,'dosen_demo_09',1),
(64,'Mahasiswa Demo 09A','mahasiswa09a@sipafik.test',NULL,'$2y$12$edP0k4Mfo4Sd/ELibpaJ5usMa3Iel9LeO7dRxBa79tfzFge8YKxZ2','mahasiswa',NULL,'2026-11-14 20:42:57','2026-11-14 20:42:57',9,'mahasiswa_demo_09a',1),
(65,'Mahasiswa Demo 09B','mahasiswa09b@sipafik.test',NULL,'$2y$12$ruVTXbPUgiKTsO69I/Afn.9A4TRW3pDJZ9WRlWei6P9qwVKa58xXq','mahasiswa',NULL,'2026-11-14 20:42:58','2026-11-14 20:42:58',9,'mahasiswa_demo_09b',1),
(66,'Organisasi Demo 10','organisasi10@sipafik.test',NULL,'$2y$12$ie0F1YjfrUHW9oGoHvZXSOc3W/4zT79UuTxsdoMQmAEy/suVOBW6u','organisasi',NULL,'2026-11-14 20:42:58','2026-11-14 20:42:58',10,'organisasi_demo_10',1),
(67,'Petugas Fasilitas 10','petugas10@sipafik.test',NULL,'$2y$12$rbs3uOPC3B7SLtzR72Vy9uqVDFJiPTqeeeWQXKTS0hed7CVpob1.2','petugas_fasilitas',NULL,'2026-11-14 20:42:58','2026-11-14 20:42:58',10,'petugas_demo_10',1),
(68,'Dosen Demo 10','dosen10@sipafik.test',NULL,'$2y$12$OwpOD6NbuDabJDXSN04LDev/lgC.d3lg4JNCN6rY5PSHlI60HjmS.','dosen',NULL,'2026-11-14 20:42:58','2026-11-14 20:42:58',10,'dosen_demo_10',1),
(69,'Mahasiswa Demo 10A','mahasiswa10a@sipafik.test',NULL,'$2y$12$ibVLbhVyxeKmEmwBGHv6t.Ly2GOy6ohEB46gC3cfh7wOsSYGFjqFe','mahasiswa',NULL,'2026-11-14 20:42:58','2026-11-14 20:42:58',10,'mahasiswa_demo_10a',1),
(70,'Mahasiswa Demo 10B','mahasiswa10b@sipafik.test',NULL,'$2y$12$suW.jttihFtc.nouddW.n.SOHxpRNNHirVct7uWtlIehBdAThhTrK','mahasiswa',NULL,'2026-11-14 20:42:59','2026-11-14 20:42:59',10,'mahasiswa_demo_10b',1),
(71,'Admin Kampus Demo 02','adminkampus02@sipafik.test',NULL,'$2y$12$/rOrXhdKNcm8ANFEqVr8muzfWpu1U/pW20lAnmrTvwPCogLbbaJLO','admin_kampus',NULL,'2026-11-17 05:46:58','2026-11-17 05:46:58',2,'adminkampus_demo_02',1),
(72,'Admin Kampus Demo 03','adminkampus03@sipafik.test',NULL,'$2y$12$MReJKo/MsnHXHnAxyyZMse483aNDTFlsYYXxTffUvxM0NDwkijOkG','admin_kampus',NULL,'2026-11-17 05:46:59','2026-11-17 05:46:59',3,'adminkampus_demo_03',1),
(73,'Admin Kampus Demo 04','adminkampus04@sipafik.test',NULL,'$2y$12$3y/BWTHfwwCEr4ppJc.vMOtr81H1bg65BOo5Ae/8TUTxdB/KhV2dm','admin_kampus',NULL,'2026-11-17 05:46:59','2026-11-17 05:46:59',4,'adminkampus_demo_04',1),
(74,'Admin Kampus Demo 05','adminkampus05@sipafik.test',NULL,'$2y$12$AosmsPP42doUqeoAVVm1NOF.BumEF5rf4Q48461/dDg7L50KzYz52','admin_kampus',NULL,'2026-11-17 05:46:59','2026-11-17 05:46:59',5,'adminkampus_demo_05',1),
(75,'Admin Kampus Demo 06','adminkampus06@sipafik.test',NULL,'$2y$12$kmAEtWTOklE6GgjxO7bw6OIYLIJlTOCHQ2/s0c8vpjbNdV7Geumou','admin_kampus',NULL,'2026-11-17 05:46:59','2026-11-17 05:46:59',6,'adminkampus_demo_06',1),
(76,'Admin Kampus Demo 07','adminkampus07@sipafik.test',NULL,'$2y$12$4CTR5p/4bF9JJ9d2jnY0f.X2qNydNVFvHvHSrLoHNSHo9acENbMQG','admin_kampus',NULL,'2026-11-17 05:46:59','2026-11-17 05:46:59',7,'adminkampus_demo_07',0),
(77,'Admin Kampus Demo 08','adminkampus08@sipafik.test',NULL,'$2y$12$iv5KoeQJnHsV5dxHt1ICTe6UBC2Prz6hzI6NuDKUAxqTLwxadA0MK','admin_kampus',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00',8,'adminkampus_demo_08',0),
(78,'Admin Kampus Demo 09','adminkampus09@sipafik.test',NULL,'$2y$12$bl0a/zAcyo5vtsoPpmUFo.l7GVYr58UX2vEfuiSeTcOZbAh8WEzD6','admin_kampus',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00',9,'adminkampus_demo_09',0),
(79,'Admin Kampus Demo 10','adminkampus10@sipafik.test',NULL,'$2y$12$x5TdL6koMd3Jw5l9C.NXROsjwwjVgDwfTyKl4ByR6GZ75EiqKtuIG','admin_kampus',NULL,'2026-11-17 05:47:00','2026-11-17 05:47:00',10,'adminkampus_demo_10',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

