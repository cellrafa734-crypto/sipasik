<?php
/**
 * ALAT BANTU: cek apakah hosting memenuhi syarat Laravel 12 / SIPAFIK.
 * Cara pakai: upload sementara ke folder yang bisa dibuka browser (mis. public_html/cek_server.php),
 * buka lewat browser, catat hasilnya, lalu SEGERA HAPUS file ini dari server.
 */
header('Content-Type: text/plain; charset=utf-8');
$ok = fn ($v) => $v ? 'OK     ' : 'GAGAL  ';
echo "PEMERIKSAAN SERVER UNTUK SIPAFIK (Laravel 12)\n==============================================\n";
echo $ok(version_compare(PHP_VERSION, '8.2.0', '>=')).'PHP '.PHP_VERSION." (minimal 8.2, disarankan 8.3)\n";
foreach (['ctype','curl','dom','fileinfo','filter','hash','mbstring','openssl','pcre','pdo','pdo_mysql','session','tokenizer','xml','json','bcmath'] as $ext) {
    echo $ok(extension_loaded($ext))."ekstensi $ext\n";
}
echo $ok(function_exists('proc_open')).'fungsi proc_open (diperlukan composer/artisan lewat SSH)'."\n";
echo $ok(ini_get('allow_url_fopen')).'allow_url_fopen'."\n";
echo $ok(is_writable(__DIR__)).'folder ini dapat ditulisi'."\n";
echo "memory_limit : ".ini_get('memory_limit')."\n";
echo "upload_max   : ".ini_get('upload_max_filesize')." (form kampus mengizinkan file 2 MB)\n";
echo "post_max     : ".ini_get('post_max_size')."\n";
echo "Server       : ".($_SERVER['SERVER_SOFTWARE'] ?? '-')."\n";
echo "Zona waktu   : ".date_default_timezone_get()."\n";
echo "\nSetelah selesai, HAPUS file ini.\n";
