# PANDUAN LOGIN DEMO SIPAFIK

> Dihasilkan dari **database aktual** (`sipafik_db`, 79 akun) dan diverifikasi dengan `Hash::check` terhadap password yang diketahui dari Seeder. Tidak ada hash password yang dicantumkan.
> **Login memakai EMAIL**, bukan username. Halaman login pengguna kampus: `/login`. Halaman login Super Admin: `/super-admin/login`.

## 1. Mulai cepat — akun yang disarankan untuk dosen penguji

Gunakan **Kampus Demo Aceh Utara (kampus 02, status Disetujui)**: seluruh dashboard-nya sudah terisi data demo.

| Role | Email | Password | Dashboard |
|---|---|---|---|
| Super Admin | `superadmin@sipafik.test` | `SIPAFIKAdmin2026!` | `/super-admin/dashboard` (login di `/super-admin/login`) |
| Admin Kampus | `adminkampus02@sipafik.test` | `DemoSipafik2026!` | `/dashboard` |
| Organisasi | `organisasi02@sipafik.test` | `DemoSipafik2026!` | `/dashboard` |
| Dosen | `dosen02@sipafik.test` | `DemoSipafik2026!` | `/dashboard` |
| Petugas Fasilitas | `petugas02@sipafik.test` | `DemoSipafik2026!` | `/dashboard` |
| Mahasiswa | `mahasiswa02a@sipafik.test` (juga `mahasiswa02b@…`) | `DemoSipafik2026!` | `/dashboard` |

Pola yang sama berlaku untuk kampus 03, 04, 05, 06 (ganti `02` dengan nomor kampus), mis. `petugas04@sipafik.test`.
Untuk menguji **akses lintas kampus**, login sebagai `mahasiswa02a` lalu coba buka data kampus 03: sistem menjawab 404.

## 2. Catatan penting

* **Akun `admin_kampus` kampus 02–06 adalah akun BARU** yang ditambahkan Seeder baru (`adminkampus02…06@sipafik.test`) karena sebelumnya kampus demo yang disetujui tidak punya Admin Kampus sama sekali. Akun kampus 07–10 (`adminkampus07…10`) dibuat dengan status **nonaktif** sesuai status kampusnya (menunggu/ditolak); akan aktif otomatis bila Super Admin menyetujui kampusnya.
* **Kampus 1 — Universitas Jabal Ghafur (UNIGHA) berstatus `pending`.** Semua akunnya dapat login (kecuali `admin@unigha.ac.id` yang nonaktif), tetapi dashboard hanya menampilkan pemberitahuan "Kampus belum disetujui". Ini sengaja tidak diubah. Alur persetujuan dapat didemonstrasikan: Super Admin → *Setujui* kampus UNIGHA → akun UNIGHA aktif (data modul UNIGHA belum ada, jadi dashboard-nya akan relatif kosong).
* **Email `tatia.demo@sipafik.test` yang disebut pada brief awal TIDAK ADA.** Yang ada di database adalah `tatia.alza.demo@sipafik.test`.
* **4 akun lama passwordnya tidak dapat diverifikasi** (`mahasiswa@sipafik.test`, `dosen@sipafik.test`, `petugas@sipafik.test`, `admin@unigha.ac.id`). Password tidak diubah. Jika dibutuhkan, minta Admin Kampus/Super Admin mengatur ulang atau gunakan akun lain.
* `admin@sipafik.test` (role lama `admin`) memakai password `Admin123!` (terverifikasi), tetapi role `admin` dan `petugas_laboratorium` adalah role lama yang tidak punya dashboard; login berhasil dan menampilkan halaman pemberitahuan. Akun-akun ini tanpa kampus dan **tidak dihubungkan otomatis ke kampus mana pun** karena tidak ada bukti asal datanya.
* Admin Kampus dari kampus yang belum disetujui **tidak dapat login** (pesan: "Akun kampus belum aktif"). Role lain dari kampus pending/rejected dapat login tetapi hanya melihat pemberitahuan status kampus.

## 3. Daftar lengkap seluruh akun

Password: `DemoSipafik2026!` untuk semua akun demo (Seeder), kecuali yang disebut berbeda pada kolom Password.

| No | Role | Nama | Email (login) | Kampus | Status Kampus | Akun | Password | Keterangan |
|---|---|---|---|---|---|---|---|---|
| 1 | Super Admin | Super Admin SIPAFIK | `superadmin@sipafik.test` | — | — | Aktif | `SIPAFIKAdmin2026!` | Dapat login → `/super-admin/dashboard` |
| 2 | Admin Kampus | Admin UNIGHA | `admin@unigha.ac.id` | Universitas Jabal Ghafur | Menunggu verifikasi | Nonaktif | *tidak terverifikasi* | Akun nonaktif → login ditolak |
| 3 | Admin Kampus | Admin Kampus Demo 02 | `adminkampus02@sipafik.test` | Kampus Demo Aceh Utara | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 4 | Admin Kampus | Admin Kampus Demo 03 | `adminkampus03@sipafik.test` | Kampus Demo Pidie Jaya | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 5 | Admin Kampus | Admin Kampus Demo 04 | `adminkampus04@sipafik.test` | Kampus Demo Bireuen | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 6 | Admin Kampus | Admin Kampus Demo 05 | `adminkampus05@sipafik.test` | Kampus Demo Banda Aceh | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 7 | Admin Kampus | Admin Kampus Demo 06 | `adminkampus06@sipafik.test` | Kampus Demo Aceh Besar | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 8 | Admin Kampus | Admin Kampus Demo 07 | `adminkampus07@sipafik.test` | Kampus Demo Pidie | Menunggu verifikasi | Nonaktif | `DemoSipafik2026!` | Akun nonaktif → login ditolak |
| 9 | Admin Kampus | Admin Kampus Demo 08 | `adminkampus08@sipafik.test` | Kampus Demo Aceh Barat | Menunggu verifikasi | Nonaktif | `DemoSipafik2026!` | Akun nonaktif → login ditolak |
| 10 | Admin Kampus | Admin Kampus Demo 09 | `adminkampus09@sipafik.test` | Kampus Demo Aceh Tengah | Menunggu verifikasi | Nonaktif | `DemoSipafik2026!` | Akun nonaktif → login ditolak |
| 11 | Admin Kampus | Admin Kampus Demo 10 | `adminkampus10@sipafik.test` | Kampus Demo Lhokseumawe | Ditolak | Nonaktif | `DemoSipafik2026!` | Akun nonaktif → login ditolak |
| 12 | Organisasi | BEM UNIGHA | `bem.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 13 | Organisasi | Himpunan Teknik Informatika | `hima.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 14 | Organisasi | Organisasi Demo 01 | `organisasi01@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 15 | Organisasi | Organisasi Demo 02 | `organisasi02@sipafik.test` | Kampus Demo Aceh Utara | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 16 | Organisasi | Organisasi Demo 03 | `organisasi03@sipafik.test` | Kampus Demo Pidie Jaya | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 17 | Organisasi | Organisasi Demo 04 | `organisasi04@sipafik.test` | Kampus Demo Bireuen | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 18 | Organisasi | Organisasi Demo 05 | `organisasi05@sipafik.test` | Kampus Demo Banda Aceh | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 19 | Organisasi | Organisasi Demo 06 | `organisasi06@sipafik.test` | Kampus Demo Aceh Besar | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 20 | Organisasi | Organisasi Demo 07 | `organisasi07@sipafik.test` | Kampus Demo Pidie | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 21 | Organisasi | Organisasi Demo 08 | `organisasi08@sipafik.test` | Kampus Demo Aceh Barat | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 22 | Organisasi | Organisasi Demo 09 | `organisasi09@sipafik.test` | Kampus Demo Aceh Tengah | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 23 | Organisasi | Organisasi Demo 10 | `organisasi10@sipafik.test` | Kampus Demo Lhokseumawe | Ditolak | Aktif | `DemoSipafik2026!` | Kampus ditolak → login berhasil, dashboard menampilkan pemberitahuan beserta alasan penolakan |
| 24 | Dosen | Dosen SIPAFIK | `dosen@sipafik.test` | — | — | Aktif | *tidak terverifikasi* | Tanpa kampus; login berhasil namun hanya melihat pemberitahuan |
| 25 | Dosen | Dosen Demo 01 | `dosen01@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 26 | Dosen | Rahmat Hidayat | `rahmat.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 27 | Dosen | Siti Nurhaliza | `siti.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 28 | Dosen | Dosen Demo 02 | `dosen02@sipafik.test` | Kampus Demo Aceh Utara | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 29 | Dosen | Dosen Demo 03 | `dosen03@sipafik.test` | Kampus Demo Pidie Jaya | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 30 | Dosen | Dosen Demo 04 | `dosen04@sipafik.test` | Kampus Demo Bireuen | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 31 | Dosen | Dosen Demo 05 | `dosen05@sipafik.test` | Kampus Demo Banda Aceh | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 32 | Dosen | Dosen Demo 06 | `dosen06@sipafik.test` | Kampus Demo Aceh Besar | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 33 | Dosen | Dosen Demo 07 | `dosen07@sipafik.test` | Kampus Demo Pidie | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 34 | Dosen | Dosen Demo 08 | `dosen08@sipafik.test` | Kampus Demo Aceh Barat | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 35 | Dosen | Dosen Demo 09 | `dosen09@sipafik.test` | Kampus Demo Aceh Tengah | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 36 | Dosen | Dosen Demo 10 | `dosen10@sipafik.test` | Kampus Demo Lhokseumawe | Ditolak | Aktif | `DemoSipafik2026!` | Kampus ditolak → login berhasil, dashboard menampilkan pemberitahuan beserta alasan penolakan |
| 37 | Petugas Fasilitas | Andi Saputra | `andi.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 38 | Petugas Fasilitas | Petugas Fasilitas 01 | `petugas01@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 39 | Petugas Fasilitas | Petugas Fasilitas 02 | `petugas02@sipafik.test` | Kampus Demo Aceh Utara | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 40 | Petugas Fasilitas | Petugas Fasilitas 03 | `petugas03@sipafik.test` | Kampus Demo Pidie Jaya | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 41 | Petugas Fasilitas | Petugas Fasilitas 04 | `petugas04@sipafik.test` | Kampus Demo Bireuen | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 42 | Petugas Fasilitas | Petugas Fasilitas 05 | `petugas05@sipafik.test` | Kampus Demo Banda Aceh | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 43 | Petugas Fasilitas | Petugas Fasilitas 06 | `petugas06@sipafik.test` | Kampus Demo Aceh Besar | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 44 | Petugas Fasilitas | Petugas Fasilitas 07 | `petugas07@sipafik.test` | Kampus Demo Pidie | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 45 | Petugas Fasilitas | Petugas Fasilitas 08 | `petugas08@sipafik.test` | Kampus Demo Aceh Barat | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 46 | Petugas Fasilitas | Petugas Fasilitas 09 | `petugas09@sipafik.test` | Kampus Demo Aceh Tengah | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 47 | Petugas Fasilitas | Petugas Fasilitas 10 | `petugas10@sipafik.test` | Kampus Demo Lhokseumawe | Ditolak | Aktif | `DemoSipafik2026!` | Kampus ditolak → login berhasil, dashboard menampilkan pemberitahuan beserta alasan penolakan |
| 48 | Mahasiswa | Mahasiswa SIPAFIK | `mahasiswa@sipafik.test` | — | — | Aktif | *tidak terverifikasi* | Tanpa kampus; login berhasil namun hanya melihat pemberitahuan |
| 49 | Mahasiswa | Aulia Putri | `aulia.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 50 | Mahasiswa | Cipa | `cipa.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 51 | Mahasiswa | Dinda Amelia | `dinda.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 52 | Mahasiswa | Fajar Ramadhan | `fajar.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 53 | Mahasiswa | Mahasiswa Demo 01A | `mahasiswa01a@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 54 | Mahasiswa | Mahasiswa Demo 01B | `mahasiswa01b@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 55 | Mahasiswa | Nabila Zahra | `nabila.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 56 | Mahasiswa | Nadia Putri | `nadia.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 57 | Mahasiswa | Rani Safitri | `rani.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 58 | Mahasiswa | Rizky Maulana | `rizky.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 59 | Mahasiswa | Tatia Alza | `tatia.alza.demo@sipafik.test` | Universitas Jabal Ghafur | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 60 | Mahasiswa | Mahasiswa Demo 02A | `mahasiswa02a@sipafik.test` | Kampus Demo Aceh Utara | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 61 | Mahasiswa | Mahasiswa Demo 02B | `mahasiswa02b@sipafik.test` | Kampus Demo Aceh Utara | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 62 | Mahasiswa | Mahasiswa Demo 03A | `mahasiswa03a@sipafik.test` | Kampus Demo Pidie Jaya | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 63 | Mahasiswa | Mahasiswa Demo 03B | `mahasiswa03b@sipafik.test` | Kampus Demo Pidie Jaya | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 64 | Mahasiswa | Mahasiswa Demo 04A | `mahasiswa04a@sipafik.test` | Kampus Demo Bireuen | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 65 | Mahasiswa | Mahasiswa Demo 04B | `mahasiswa04b@sipafik.test` | Kampus Demo Bireuen | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 66 | Mahasiswa | Mahasiswa Demo 05A | `mahasiswa05a@sipafik.test` | Kampus Demo Banda Aceh | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 67 | Mahasiswa | Mahasiswa Demo 05B | `mahasiswa05b@sipafik.test` | Kampus Demo Banda Aceh | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 68 | Mahasiswa | Mahasiswa Demo 06A | `mahasiswa06a@sipafik.test` | Kampus Demo Aceh Besar | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 69 | Mahasiswa | Mahasiswa Demo 06B | `mahasiswa06b@sipafik.test` | Kampus Demo Aceh Besar | Disetujui | Aktif | `DemoSipafik2026!` | Dapat login → `/dashboard` (penuh) |
| 70 | Mahasiswa | Mahasiswa Demo 07A | `mahasiswa07a@sipafik.test` | Kampus Demo Pidie | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 71 | Mahasiswa | Mahasiswa Demo 07B | `mahasiswa07b@sipafik.test` | Kampus Demo Pidie | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 72 | Mahasiswa | Mahasiswa Demo 08A | `mahasiswa08a@sipafik.test` | Kampus Demo Aceh Barat | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 73 | Mahasiswa | Mahasiswa Demo 08B | `mahasiswa08b@sipafik.test` | Kampus Demo Aceh Barat | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 74 | Mahasiswa | Mahasiswa Demo 09A | `mahasiswa09a@sipafik.test` | Kampus Demo Aceh Tengah | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 75 | Mahasiswa | Mahasiswa Demo 09B | `mahasiswa09b@sipafik.test` | Kampus Demo Aceh Tengah | Menunggu verifikasi | Aktif | `DemoSipafik2026!` | Kampus belum disetujui → login berhasil, dashboard menampilkan pemberitahuan |
| 76 | Mahasiswa | Mahasiswa Demo 10A | `mahasiswa10a@sipafik.test` | Kampus Demo Lhokseumawe | Ditolak | Aktif | `DemoSipafik2026!` | Kampus ditolak → login berhasil, dashboard menampilkan pemberitahuan beserta alasan penolakan |
| 77 | Mahasiswa | Mahasiswa Demo 10B | `mahasiswa10b@sipafik.test` | Kampus Demo Lhokseumawe | Ditolak | Aktif | `DemoSipafik2026!` | Kampus ditolak → login berhasil, dashboard menampilkan pemberitahuan beserta alasan penolakan |
| 78 | Admin (role lama) | Admin SIPAFIK | `admin@sipafik.test` | — | — | Aktif | `Admin123!` | Role lama; login berhasil namun hanya melihat halaman pemberitahuan (belum ada dashboard) |
| 79 | Petugas Laboratorium (role lama) | Petugas Laboratorium | `petugas@sipafik.test` | — | — | Aktif | *tidak terverifikasi* | Role lama; login berhasil namun hanya melihat halaman pemberitahuan (belum ada dashboard) |
