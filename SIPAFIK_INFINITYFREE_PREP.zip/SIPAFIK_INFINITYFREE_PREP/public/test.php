<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

$core = __DIR__ . '/sipafik_core';

echo "<h2>TES BOOTSTRAP LARAVEL</h2>";

try {
    $autoload = $core . '/vendor/autoload.php';
    $bootstrap = $core . '/bootstrap/app.php';

    echo "Autoload: " . (file_exists($autoload) ? "ADA" : "HILANG") . "<br>";
    echo "Bootstrap: " . (file_exists($bootstrap) ? "ADA" : "HILANG") . "<br>";

    require $autoload;
    $app = require $bootstrap;

    echo "<h3>BOOTSTRAP BERHASIL</h3>";
    echo "Class: " . get_class($app);
} catch (Throwable $e) {
    echo "<h3>BOOTSTRAP GAGAL</h3>";
    echo "Pesan: " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "File: " . htmlspecialchars($e->getFile()) . "<br>";
    echo "Baris: " . $e->getLine();
}
