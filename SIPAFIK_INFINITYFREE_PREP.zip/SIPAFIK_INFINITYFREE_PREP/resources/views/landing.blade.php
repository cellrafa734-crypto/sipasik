<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="SIPAFIK - Sistem Informasi Pengelolaan Kegiatan dan Fasilitas Pendukung Event Kampus Berbasis Web.">
  <title>SIPAFIK — Campus Events & Facilities</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="{{ asset('sipafik/css/style.css') }}">
</head>
<body>
  <header class="navbar">
    <a class="brand" href="#home"><span class="brand-mark">S</span><span>SIPAFIK<small>CAMPUS MANAGEMENT</small></span></a>
    <button class="menu-toggle" aria-label="Buka menu">☰</button>
    <nav class="nav-links">
      <a href="#home">Beranda</a>
      <a href="#about">Tentang</a>
      <a href="#events">Kegiatan</a>
      <a href="#facilities">Fasilitas</a>
      <a href="#roles">Pengguna</a>
    </nav>
    <div class="nav-actions"><a class="nav-login" href="{{ route('login') }}">Login</a><a class="nav-cta" href="{{ route('campus.register') }}">Daftar Kampus <span>↗</span></a></div>
  </header>

  <main>
    <section class="hero" id="home">
      <video class="hero-video" autoplay muted loop playsinline poster="{{ asset('sipafik/assets/images/events/kegiatan-mahasiswa.jpg') }}">
        <source src="{{ asset('sipafik/assets/videos/hero-event.mp4') }}" type="video/mp4">
      </video>
      <div class="hero-shade"></div>
      <div class="hero-content reveal">
        <div class="eyebrow light"><span></span> CAMPUS EVENTS & FACILITIES PLATFORM</div>
        <p class="hero-kicker">Satu ruang untuk setiap kegiatan kampus.</p>
        <h1>Sistem Informasi Pengelolaan Kegiatan dan Fasilitas Pendukung Event Kampus Berbasis Web <em>(SIPAFIK).</em></h1>
        <p class="hero-desc">Menghubungkan informasi kegiatan, pendaftaran peserta, jadwal, dan fasilitas pendukung dalam satu sistem yang terintegrasi.</p>
        <div class="hero-actions">
          <a class="button button-light" href="#about">Jelajahi SIPAFIK <span>↗</span></a>
          <a class="text-link" href="#events">Kenali kegiatannya ↓</a>
        </div>
      </div>
      <div class="hero-note"><span>01 / 04</span><span>DESIGNED FOR CAMPUS LIFE</span></div>
      <div class="hero-orbit orbit-one"></div><div class="hero-orbit orbit-two"></div>
    </section>

    <section class="intro section-pad" id="about">
      <div class="section-label reveal">01 — TENTANG SIPAFIK</div>
      <div class="intro-grid">
        <div class="intro-visual reveal">
          <div class="slideshow">
            <img class="slide active" src="{{ asset('sipafik/assets/images/events/kegiatan-mahasiswa.jpg') }}" alt="Suasana kegiatan kampus">
            <img class="slide" src="{{ asset('sipafik/assets/images/events/seminar.jpg') }}" alt="Seminar kampus">
            <img class="slide" src="{{ asset('sipafik/assets/images/events/workshop.jpg') }}" alt="Workshop mahasiswa">
            <img class="slide" src="{{ asset('sipafik/assets/images/events/kegiatan-mahasiswa.jpg') }}" alt="Aktivitas mahasiswa">
          </div>
          <div class="visual-caption"><span>SPACES THAT BRING IDEAS TO LIFE</span><span>✳</span></div>
          <div class="floating-stamp">CAMPUS<br>CONNECTED</div>
        </div>
        <div class="intro-copy reveal">
          <div class="eyebrow"><span></span> ABOUT THE PLATFORM</div>
          <h2>Setiap kegiatan punya cerita. <em>Setiap ruang punya peran.</em></h2>
          <p>SIPAFIK merupakan sistem informasi berbasis web yang dirancang untuk membantu pengelolaan kegiatan kampus dan fasilitas pendukungnya.</p>
          <p>Melalui satu platform, informasi event, proses pendaftaran peserta, jadwal kegiatan, serta kebutuhan fasilitas dapat dikelola dengan lebih terarah.</p>
          <div class="intro-stat"><strong>01</strong><span>Platform terpadu untuk mendukung aktivitas dan penyelenggaraan event kampus.</span></div>
        </div>
      </div>
    </section>

    <section class="features section-pad">
      <div class="section-label reveal">02 — DALAM SATU PLATFORM</div>
      <div class="section-heading reveal"><h2>Hal penting, <em>terhubung.</em></h2><p>Informasi yang dibutuhkan untuk mendukung kegiatan kampus dalam satu alur pengelolaan.</p></div>
      <div class="feature-grid">
        <article class="feature-card reveal"><span class="feature-number">01</span><div class="feature-icon">✳</div><h3>Informasi Event</h3><p>Menampilkan informasi kegiatan kampus agar mudah diketahui oleh calon peserta.</p><span class="card-arrow">↗</span></article>
        <article class="feature-card reveal"><span class="feature-number">02</span><div class="feature-icon">◎</div><h3>Pendaftaran Peserta</h3><p>Mendukung proses pendaftaran dan pengelolaan data peserta kegiatan.</p><span class="card-arrow">↗</span></article>
        <article class="feature-card reveal"><span class="feature-number">03</span><div class="feature-icon">◷</div><h3>Jadwal Kegiatan</h3><p>Membantu penyusunan dan penyampaian jadwal kegiatan secara terstruktur.</p><span class="card-arrow">↗</span></article>
        <article class="feature-card reveal"><span class="feature-number">04</span><div class="feature-icon">⌂</div><h3>Fasilitas Pendukung</h3><p>Mendukung pengelolaan kebutuhan ruang, aula, laboratorium, dan fasilitas kampus lainnya.</p><span class="card-arrow">↗</span></article>
      </div>
    </section>

    <section class="events section-pad" id="events">
      <div class="section-label reveal">03 — KEGIATAN KAMPUS</div>
      <div class="section-heading reveal"><h2>Ruang untuk <em>berkembang.</em></h2><p>Berbagai jenis kegiatan yang dapat diperkenalkan dan dikelola melalui SIPAFIK.</p></div>
      <div class="editorial-grid">
        <article class="editorial-card large reveal"><img src="{{ asset('sipafik/assets/images/events/seminar.jpg') }}" alt="Seminar kampus"><div class="editorial-overlay"><span>01 / KNOWLEDGE</span><h3>Seminar & Diskusi</h3><p>Tempat bertukar gagasan, wawasan, dan pengalaman.</p></div></article>
        <article class="editorial-card reveal"><img src="{{ asset('sipafik/assets/images/events/workshop.jpg') }}" alt="Workshop mahasiswa"><div class="editorial-overlay"><span>02 / EXPERIENCE</span><h3>Workshop</h3><p>Belajar melalui pengalaman dan praktik.</p></div></article>
        <article class="editorial-card reveal"><img src="{{ asset('sipafik/assets/images/events/kegiatan-mahasiswa.jpg') }}" alt="Kegiatan organisasi mahasiswa"><div class="editorial-overlay"><span>03 / COMMUNITY</span><h3>Kegiatan Mahasiswa</h3><p>Mendukung kolaborasi dan kreativitas.</p></div></article>
      </div>
    </section>

    <section class="facilities section-pad" id="facilities">
      <div class="section-label reveal">04 — FASILITAS PENDUKUNG</div>
      <div class="section-heading reveal"><h2>Tempat yang mendukung <em>setiap ide.</em></h2><p>Fasilitas kampus menjadi bagian penting dalam kelancaran penyelenggaraan kegiatan.</p></div>
      <div class="facility-grid">
        <article class="facility-card reveal"><img src="{{ asset('sipafik/assets/images/facilities/aula-kampus.jpg') }}" alt="Aula kampus"><div><span>SPACE / 01</span><h3>Aula Kampus</h3><p>Untuk seminar, pertemuan, dan kegiatan berskala besar.</p></div></article>
        <article class="facility-card reveal"><img src="{{ asset('sipafik/assets/images/facilities/laboratorium.jpg') }}" alt="Laboratorium"><div><span>SPACE / 02</span><h3>Laboratorium</h3><p>Untuk kegiatan praktik, pelatihan, dan pembelajaran.</p></div></article>
        <article class="facility-card reveal"><img src="{{ asset('sipafik/assets/images/facilities/ruang-pertemuan.jpg') }}" alt="Ruang pertemuan"><div><span>SPACE / 03</span><h3>Ruang Pertemuan</h3><p>Untuk rapat, koordinasi, dan diskusi kelompok.</p></div></article>
      </div>
    </section>

    <section class="workflow section-pad">
      <div class="section-label reveal">05 — ALUR PENGELOLAAN</div>
      <div class="section-heading reveal"><h2>Dari rencana menjadi <em>kegiatan.</em></h2><p>Gambaran umum alur pengelolaan kegiatan dan fasilitas pendukungnya.</p></div>
      <div class="steps">
        <article class="step reveal"><span>01</span><div><h3>Publikasikan</h3><p>Informasi kegiatan disiapkan dan diperkenalkan kepada calon peserta.</p></div></article>
        <article class="step reveal"><span>02</span><div><h3>Daftarkan</h3><p>Peserta memperoleh informasi dan melakukan pendaftaran kegiatan.</p></div></article>
        <article class="step reveal"><span>03</span><div><h3>Atur Kebutuhan</h3><p>Jadwal serta kebutuhan fasilitas pendukung dikelola sesuai kegiatan.</p></div></article>
        <article class="step reveal"><span>04</span><div><h3>Laksanakan</h3><p>Kegiatan dijalankan dengan informasi dan kebutuhan yang lebih terarah.</p></div></article>
      </div>
    </section>

    <section class="roles section-pad" id="roles">
      <div class="section-label reveal">06 — PENGGUNA SISTEM</div>
      <div class="section-heading reveal"><h2>Enam peran, satu <em>tujuan.</em></h2><p>Setiap pengguna memiliki peran sesuai kebutuhan pengelolaan kegiatan dan fasilitas kampus.</p></div>
      <div class="role-grid role-grid-six">
        <article class="role-card reveal"><span>01</span><div class="role-symbol">◇</div><h3>Super Admin</h3><p>Memverifikasi kampus dan mengawasi platform SIPAFIK secara keseluruhan.</p></article>
        <article class="role-card reveal"><span>02</span><div class="role-symbol">⌂</div><h3>Admin Kampus</h3><p>Mengelola data kampus, pengguna, fasilitas, dan aktivitas di lingkungan kampus.</p></article>
        <article class="role-card reveal"><span>03</span><div class="role-symbol">✳</div><h3>Organisasi</h3><p>Mengelola kegiatan organisasi, pendaftaran peserta, jadwal event, dan pengajuan fasilitas.</p></article>
        <article class="role-card reveal"><span>04</span><div class="role-symbol">▤</div><h3>Dosen</h3><p>Mengelola kegiatan akademik, memantau peserta, jadwal laboratorium, dan kebutuhan fasilitas.</p></article>
        <article class="role-card reveal"><span>05</span><div class="role-symbol">▦</div><h3>Petugas Fasilitas</h3><p>Memeriksa ketersediaan, mengelola ruang, dan memproses permohonan fasilitas.</p></article>
        <article class="role-card reveal"><span>06</span><div class="role-symbol">♧</div><h3>Mahasiswa</h3><p>Melihat kegiatan, mendaftar event, dan mengajukan fasilitas sesuai ketentuan kampus.</p></article>
      </div>
    </section>

    <section class="closing">
      <div class="closing-inner reveal"><div class="eyebrow light"><span></span> SIPAFIK / CAMPUS LIFE</div><h2>Kelola kegiatan.<br><em>Hubungkan fasilitas.</em></h2><p>Mendukung pengelolaan kegiatan kampus melalui informasi yang lebih terarah dan terintegrasi.</p><a class="button button-light" href="#home">Kembali ke atas ↑</a></div>
      <div class="closing-orbit"></div>
    </section>
  <section class="campus-gallery" id="galeri">
    <div class="gallery-heading">
        <span class="section-label">GALERI KEGIATAN</span>
        <h2>Suasana Kegiatan dan Fasilitas Kampus</h2>
        <p>Gambaran kegiatan mahasiswa dan fasilitas pendukung kegiatan kampus.</p>
    </div>

    <div class="gallery-grid">
        <article class="gallery-card gallery-large">
            <img src="{{ asset('sipafik/assets/images/events/seminar.jpg') }}" alt="Seminar kampus">
            <div class="gallery-caption"><h3>Seminar Kampus</h3><p>Kegiatan berbagi ilmu dan wawasan.</p></div>
        </article>
        <article class="gallery-card">
            <img src="{{ asset('sipafik/assets/images/events/workshop.jpg') }}" alt="Workshop">
            <div class="gallery-caption"><h3>Workshop</h3><p>Pelatihan dan pengembangan keterampilan.</p></div>
        </article>
        <article class="gallery-card">
            <img src="{{ asset('sipafik/assets/images/events/kegiatan-mahasiswa.jpg') }}" alt="Kegiatan mahasiswa">
            <div class="gallery-caption"><h3>Kegiatan Mahasiswa</h3><p>Aktivitas dan kolaborasi mahasiswa.</p></div>
        </article>
        <article class="gallery-card">
            <img src="{{ asset('sipafik/assets/images/facilities/aula-kampus.jpg') }}" alt="Aula kampus">
            <div class="gallery-caption"><h3>Aula Kampus</h3><p>Tempat pelaksanaan kegiatan berskala besar.</p></div>
        </article>
        <article class="gallery-card">
            <img src="{{ asset('sipafik/assets/images/facilities/laboratorium.jpg') }}" alt="Laboratorium">
            <div class="gallery-caption"><h3>Laboratorium</h3><p>Fasilitas pendukung kegiatan praktik.</p></div>
        </article>
        <article class="gallery-card">
            <img src="{{ asset('sipafik/assets/images/facilities/ruang-pertemuan.jpg') }}" alt="Ruang pertemuan">
            <div class="gallery-caption"><h3>Ruang Pertemuan</h3><p>Tempat diskusi dan koordinasi kegiatan.</p></div>
        </article>
    </div>
</section>
  </main>

  <footer class="footer"><a class="brand" href="#home"><span class="brand-mark">S</span><span>SIPAFIK<small>CAMPUS MANAGEMENT</small></span></a><p>Sistem Informasi Pengelolaan Kegiatan dan Fasilitas Pendukung Event Kampus Berbasis Web.</p><span>© 2026 SIPAFIK — Campus Events & Facilities</span></footer>
  <script src="{{ asset('sipafik/js/script.js') }}"></script>
</body>

</html>
